﻿using System;

namespace _8.Anonymous_Threat
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

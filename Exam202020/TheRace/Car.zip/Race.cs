﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TheRace
{
    public class Race
    {
        private List<Racer> data;

        public Race(string name, int capacity)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.data = new List<Racer>();
        }


        public string Name { get; set; }
        public int Capacity { get; set; }
        public int Count => this.data.Count;

        //	Field data – collection that holds added Racers V
        //	Method Add(Racer Racer) – adds an entity to the data if there is room for him/her. V
        //	Method Remove(string name) – removes an Racer by given name, if such exists, and returns bool. V
        //	Method GetOldestRacer() – returns the oldest Racer.V
        //	Method GetRacer(string name) – returns the Racer with the given name.V

        //Getter Count – returns the number of Racers.
        //	Report() – returns a string in the following format:
        //   "Racers participating at {RaceName}:
        //{ Racer1}

        public void Add(Racer racer)
        {
            if (this.Capacity > data.Count)
            {
                this.data.Add(racer);
            }
        }
        public bool Remove(string name)
            => this.data
            .Remove(this.data.Where(x => x.Name == name)
            .FirstOrDefault());
        
        public Racer GetOldestRacer()
        {
            var oldest = this.data.OrderByDescending(x => x.Age).FirstOrDefault();

            return oldest;
        }


        public Racer GetRacer(string name)
        {
            var getName = this.data.FirstOrDefault(x => x.Name == name);

            return getName;
        }
        //	Method GetFastestRacer() – returns the Racer whose car has the highest speed.
        public Racer GetFastestRacer()
        {
            Racer fastCar = data.OrderByDescending(x => x.Car.Speed).FirstOrDefault();
            return fastCar;

        }

        public string Report()
        {
            StringBuilder result = new StringBuilder();

            result.AppendLine($"Racers participating at {this.Name}:");

            foreach (var player in data)
            {
                result.AppendLine(player.ToString());
            }

            return result.ToString().TrimEnd();
        }
    }
}
        

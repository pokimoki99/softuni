﻿using System;
using System.Collections.Generic;
using System.Text;

namespace 01. Define a Class Person
{
    class Person
{
}
}
